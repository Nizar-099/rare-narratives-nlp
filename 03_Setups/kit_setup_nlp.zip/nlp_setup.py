"""Data and evaluation setup. No model training or automatic package installation."""
from pathlib import Path
import collections
import csv
import hashlib
import importlib.metadata
import json
import os
import random
import unicodedata
import uuid
import zipfile
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import f1_score

LANGUAGES = ['EN', 'BG', 'HI', 'PT', 'RU']
EXPECTED_TRAIN = {'EN':399, 'BG':401, 'HI':366, 'PT':400, 'RU':133}
EXPECTED_TEST = {'EN':41, 'BG':35, 'HI':35, 'PT':35, 'RU':32}
ALIAS = {"URW: Discrediting Ukraine: Rewriting Ukraine's history":
         'URW: Discrediting Ukraine: Rewriting Ukraine’s history'}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def normalized_hash(text):
    return digest(' '.join(text.split()).encode('utf-8'))

def save_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

class Source:
    """Read exact archive paths or the corresponding extracted directory."""
    def __init__(self, path):
        self.path = Path(path)
        self.archive = zipfile.ZipFile(self.path) if self.path.is_file() else None

    def read(self, relative):
        return self.archive.read(relative) if self.archive else (self.path / relative).read_bytes()

    def names(self):
        if self.archive:
            return [n for n in self.archive.namelist() if not n.endswith('/')]
        return [p.relative_to(self.path).as_posix() for p in self.path.rglob('*') if p.is_file()]

def locate_source(input_root, archive_name, top_folder, override=None):
    if override:
        return Source(override)
    root = Path(input_root)
    archives = list(root.rglob(archive_name))
    if len(archives) == 1:
        return Source(archives[0])
    require(not archives, f'Più copie di {archive_name}: impostare un percorso esplicito.')
    candidates = []
    for p in root.rglob('subtask-2-annotations.txt'):
        if p.parent.name == 'EN' and p.parent.parent.name == top_folder:
            candidates.append(p.parent.parent.parent)
    candidates = sorted(set(candidates))
    require(len(candidates) == 1,
            f'Non identifico univocamente {archive_name}/{top_folder}: {candidates}. Aggiungere i dati o impostare override.')
    return Source(candidates[0])

def load_training(source, taxonomy):
    records = []
    for lang in LANGUAGES:
        data = source.read(f'training/{lang}/subtask-2-annotations.txt').decode('utf-8-sig')
        ids = set()
        for line in data.splitlines():
            if not line.strip():
                continue
            fields = line.split('\t')
            require(len(fields) == 3, f'Riga TSV non valida: {lang}')
            doc_id, coarse_raw, fine_raw = fields
            require(doc_id not in ids, f'ID duplicato: {lang}/{doc_id}')
            ids.add(doc_id)
            raw = source.read(f'training/{lang}/raw-documents/{doc_id}')
            text = raw.decode('utf-8-sig')
            require(bool(text.strip()), f'Testo vuoto: {doc_id}')
            coarse = [ALIAS.get(unicodedata.normalize('NFC', s.strip()), unicodedata.normalize('NFC', s.strip())) for s in coarse_raw.split(';')]
            fine = [ALIAS.get(unicodedata.normalize('NFC', s.strip()), unicodedata.normalize('NFC', s.strip())) for s in fine_raw.split(';')]
            require(set(coarse) <= set(taxonomy['coarse']), f'Coarse sconosciute: {doc_id}')
            require(set(fine) <= set(taxonomy['fine']), f'Fine sconosciute: {doc_id}: {set(fine)-set(taxonomy["fine"])}')
            repeated_labels = (len(coarse)-len(set(coarse))) + (len(fine)-len(set(fine)))
            # Multi-label targets are sets. Preserve raw row hash; log removed repetitions.
            coarse, fine = list(dict.fromkeys(coarse)), list(dict.fromkeys(fine))
            for labels in (coarse, fine):
                require(not ('Other' in labels and len(labels)>1), f'Other misto: {doc_id}')
            require(all(l == 'Other' or l.rsplit(': ',1)[0] in coarse for l in fine), f'Padre mancante: {doc_id}')
            records.append(dict(key=f'train/{lang}/{doc_id}', split='train', language=lang,
                                document_id=doc_id, text=text, coarse=coarse, fine=fine,
                                raw_sha256=digest(raw), label_sha256=digest(line.encode('utf-8')),
                                text_hash=normalized_hash(text), repeated_labels_removed=repeated_labels))
        require(len(ids) == EXPECTED_TRAIN[lang], f'Conteggio training inatteso: {lang}/{len(ids)}')
    return records

def load_course_texts(source):
    # Test annotations are intentionally not read: only article text for leakage checks.
    records = []
    for lang in LANGUAGES:
        prefix = f'test/{lang}/subtask-2-documents/'
        names = sorted(n for n in source.names() if n.startswith(prefix) and n.endswith('.txt'))
        require(len(names) == EXPECTED_TEST[lang], f'Conteggio documenti test inatteso: {lang}/{len(names)}')
        for name in names:
            raw = source.read(name)
            text = raw.decode('utf-8-sig')
            require(bool(text.strip()), f'Testo test vuoto: {name}')
            doc_id = name.rsplit('/',1)[1]
            records.append(dict(key=f'course_test/{lang}/{doc_id}', split='course_test', language=lang,
                                document_id=doc_id, text=text, raw_sha256=digest(raw),
                                text_hash=normalized_hash(text)))
    return records

def fingerprint_records(records):
    payload = [(r['key'],r['raw_sha256'],r.get('label_sha256')) for r in sorted(records,key=lambda r:r['key'])]
    return digest(json.dumps(payload,ensure_ascii=False).encode('utf-8'))

def audit_similarity(train, course_texts, threshold=.80):
    """Lexical screening, not proof of semantic equivalence or translation detection.

    TF-IDF here is exclusively an audit instrument, never a model feature matrix.
    Conservatively group all candidates >= threshold; do not modify gold labels.
    """
    records = sorted(train+course_texts, key=lambda r:r['key'])
    lookup = {r['key']:r for r in records}
    parent = {r['key']:r['key'] for r in records}
    def find(k):
        while parent[k] != k:
            parent[k] = parent[parent[k]]
            k = parent[k]
        return k
    def union(a,b):
        a,b=find(a),find(b)
        parent[max(a,b)] = min(a,b)
    pairs = {}
    hashes = collections.defaultdict(list)
    for r in records:
        hashes[r['text_hash']].append(r['key'])
    for members in hashes.values():
        for i,a in enumerate(members):
            for b in members[i+1:]:
                union(a,b)
                pairs[(a,b)] = {'a':a,'b':b,'cosine':None,'exact_whitespace':True}
    for lang in LANGUAGES:
        subset = [r for r in records if r['language']==lang]
        matrix = TfidfVectorizer(ngram_range=(3,3), dtype=np.float64).fit_transform([r['text'] for r in subset])
        sims = (matrix @ matrix.T).tocoo()
        for i,j,value in zip(sims.row,sims.col,sims.data):
            if i>=j or value < threshold:
                continue
            a,b=sorted([subset[i]['key'],subset[j]['key']])
            union(a,b)
            pairs[(a,b)]={'a':a,'b':b,'cosine':float(min(value,1.0)),
                           'exact_whitespace':lookup[a]['text_hash']==lookup[b]['text_hash']}
    groups = collections.defaultdict(list)
    for key in parent:
        groups[find(key)].append(key)
    # Exclude train nodes in any connected component that contains a course-test node.
    excluded = sorted(k for members in groups.values() if any(k.startswith('course_test/') for k in members)
                      for k in members if k.startswith('train/'))
    return {'threshold':threshold,'pairs':sorted(pairs.values(),key=lambda p:(p['a'],p['b'])),
            'groups':dict(groups),'excluded_training_keys':excluded}

def validate_manifest(train, similarity, manifest_path):
    manifest = pd.read_csv(manifest_path, dtype={'fold':int})
    en = {r['document_id']:r for r in train if r['language']=='EN'}
    require(len(manifest)==1197, 'Manifest incompleto.')
    require(set(manifest.fold)=={1,2,3}, 'Fold inattesi.')
    require(set(manifest.partition)=={'inner_train','inner_validation','outer_evaluation'}, 'Partizioni inattese.')
    for fold in (1,2,3):
        part = manifest[manifest.fold==fold]
        require(len(part)==399 and set(part.document_id)==set(en), f'ID mancanti/duplicati fold {fold}')
        roles = dict(zip(part.document_id,part.partition))
        for row in part.itertuples():
            require(row.raw_sha256==en[row.document_id]['raw_sha256'],f'Documento modificato: {row.document_id}')
        require(part.groupby('leakage_group_id').partition.nunique().max()==1,'Gruppo manifest diviso.')
        for members in similarity['groups'].values():
            ids=[k.rsplit('/',1)[1] for k in members if k.startswith('train/EN/')]
            require(len({roles[i] for i in ids})<=1,f'Quasi-duplicati divisi nel fold {fold}: {ids}')
    external = manifest[manifest.partition=='outer_evaluation']
    require(len(external)==399 and external.document_id.nunique()==399,'Valutazione esterna non univoca.')
    require(not any(k.startswith('train/EN/') for k in similarity['excluded_training_keys']),
            'Overlap EN/test: necessario rigenerare gli split prima di procedere.')
    return manifest

def make_fold(train, manifest, similarity, fold=1, multilingual=False):
    require(fold in (1,2,3),'Fold non valido.')
    assignments=manifest[manifest.fold==fold].set_index('document_id').partition.to_dict()
    excluded=set(similarity['excluded_training_keys'])
    data={role:[] for role in ('inner_train','inner_validation','outer_evaluation')}
    for r in train:
        if r['language']=='EN':
            data[assignments[r['document_id']]].append(r)
        elif multilingual and r['key'] not in excluded:
            data['inner_train'].append(r)
    # Also prevent any detected auxiliary-language component from crossing EN partitions.
    heldout={r['key'] for role in ('inner_validation','outer_evaluation') for r in data[role]}
    forbidden=set()
    for members in similarity['groups'].values():
        if heldout.intersection(members): forbidden.update(members)
    data['inner_train']=[r for r in data['inner_train'] if r['key'] not in forbidden]
    return data

def binary_labels(label_lists, classes):
    index={label:i for i,label in enumerate(classes)}
    require(len(index)==len(classes),'Classi duplicate.')
    y=np.zeros((len(label_lists),len(classes)),dtype=np.int32)
    for i,labels in enumerate(label_lists):
        require(set(labels)<=set(index),f'Etichette sconosciute: {set(labels)-set(index)}')
        for label in labels:y[i,index[label]]=1
    return y

def sample_f1_strict(gold, predicted, classes):
    require(len(gold)==len(predicted) and len(gold)>0,'Lunghezze non valide.')
    y,p=binary_labels(gold,classes),binary_labels(predicted,classes)
    denom=y.sum(axis=1)+p.sum(axis=1)
    scores=np.divide(2*(y*p).sum(axis=1),denom,out=np.zeros(len(y),dtype=float),where=denom!=0)
    return {'mean':float(scores.mean()),'document_std':float(scores.std())}

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    # PYTHONHASHSEED must be set before interpreter startup; do not claim to change it here.
    try:
        import torch
    except ImportError:
        return
    torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic=True
    torch.backends.cudnn.benchmark=False
    torch.use_deterministic_algorithms(True,warn_only=True)

def environment_info():
    import platform
    info={'python':platform.python_version(),'platform':platform.platform(),'packages':{}}
    for name in ['numpy','pandas','scikit-learn','torch','transformers','tokenizers']:
        try:info['packages'][name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:info['packages'][name]=None
    try:
        import torch
        info['gpu']=[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
        info['cuda_runtime']=torch.version.cuda
    except ImportError:info['gpu']=[]
    return info

def create_run_directory(output_root, config):
    """Call once per future experiment; never overwrite a checkpoint from another run."""
    for field in ['system','fold','seed','split_version','taxonomy_version']:
        require(field in config,f'Configurazione senza {field}')
    safe_system=''.join(c if c.isalnum() or c in '-_' else '_' for c in config['system'])
    name=f'{safe_system}_fold{config["fold"]}_seed{config["seed"]}_{uuid.uuid4().hex[:12]}'
    path=Path(output_root)/'runs'/name
    path.mkdir(parents=True,exist_ok=False)
    save_json(path/'config.json',config)
    save_json(path/'environment.json',environment_info())
    save_json(path/'status.json',{'state':'created','utc':datetime.now(timezone.utc).isoformat()})
    return path
